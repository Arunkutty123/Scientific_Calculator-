﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scientific_Calculator
{
    public partial class Form1 : Form
    {
        double enterFirstValue, enterSecondValue;
        String op;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Width = 390; //816
            TxtResult.Width = 318;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (TxtResult.Text.Length > 0)
            {
                TxtResult.Text = TxtResult.Text.Remove(TxtResult.Text.Length - 1, 1);
            }
            if (TxtResult.Text == "")
            {
                TxtResult.Text = "0";
            }
        }

        private void EnterNumbers(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (TxtResult.Text == "0")
                TxtResult.Text = "";
            {
                if (num.Text == ".")
                {
                    if (!TxtResult.Text.Contains("."))
                        TxtResult.Text = TxtResult.Text + num.Text;
                }
                else
                {
                    TxtResult.Text = TxtResult.Text + num.Text;
                }
            }
        }

        private void numberOper(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            enterFirstValue = Convert.ToDouble(TxtResult.Text);
            op = num.Text;
            TxtResult.Text = "";
        }

        private void BtnEqual_Click(object sender, EventArgs e)
        {
            enterSecondValue = Convert.ToDouble(TxtResult.Text);

            switch (op)
            {
                case "+":
                    TxtResult.Text = (enterFirstValue + enterSecondValue).ToString();
                    break;

                case "-":
                    TxtResult.Text = (enterFirstValue - enterSecondValue).ToString();
                    break;

                case "*":
                    TxtResult.Text = (enterFirstValue * enterSecondValue).ToString();
                    break;

                case "/":
                    TxtResult.Text = (enterFirstValue / enterSecondValue).ToString();
                    break;

                case "Mod":
                    TxtResult.Text = (enterFirstValue % enterSecondValue).ToString();
                    break;

                case "Exp":
                    double i = Convert.ToDouble(TxtResult.Text);
                    double j ;
                    j = enterSecondValue;
                    TxtResult.Text = Math.Exp(i * Math.Log(j * 4)).ToString();
                    break;

                default:
                    break;
        }

        }

        private void BtnC_Click(object sender, EventArgs e)
        {
            TxtResult.Text = "0";


        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtResult.Text = "0";

            String f,s;

            f = Convert.ToString(enterFirstValue);
            s = Convert.ToString(enterSecondValue);

            f = "";
            s = "";
          
        }

        private void BtnMinPlus_Click(object sender, EventArgs e)
        {
            double q = Convert.ToDouble(TxtResult.Text);
            TxtResult.Text = Convert.ToString(-1 * q);
        }

        private void standardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 390; //816
            TxtResult.Width = 318;
        }

        private void scientificToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 720; //816
            TxtResult.Width = 665;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult exitCal;
            exitCal = MessageBox.Show("Confrim if you want to exit ", "Scientific Calculator",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (exitCal == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            TxtResult.Text = "3.141592653589976323";
        }

        private void BtnLog_Click(object sender, EventArgs e)
        {
            double logg = Convert.ToDouble(TxtResult.Text);
            logg = Math.Log10(logg);
            TxtResult.Text = Convert.ToString(logg);
        }

        private void BtnSqrt_Click(object sender, EventArgs e)
        {
            double sq = Convert.ToDouble(TxtResult.Text);
            sq = Math.Sqrt(sq);
            TxtResult.Text = Convert.ToString(sq);

        }

        private void Btnx2_Click(object sender, EventArgs e)
        {
            double x;
            x = Convert.ToDouble(TxtResult.Text) * Convert.ToDouble(TxtResult.Text);
            TxtResult.Text = Convert.ToString(x);
        }

        private void BtnX3_Click(object sender, EventArgs e)
        {
            double x,q,p,m;
            q = Convert.ToDouble(TxtResult.Text);
            p = Convert.ToDouble(TxtResult.Text);
            m = Convert.ToDouble(TxtResult.Text);

            x = (q * p * m);
            TxtResult.Text = Convert.ToString(x);

        }

        private void BtnSinh_Click(object sender, EventArgs e)
        {
            double sh = Convert.ToDouble(TxtResult.Text);
            sh = Math.Sinh(sh);
            TxtResult.Text = Convert.ToString(sh);
        }

        private void BtnSin_Click(object sender, EventArgs e)
        {
            double sin = Convert.ToDouble(TxtResult.Text);
            sin = Math.Sin(sin);
            TxtResult.Text = Convert.ToString(sin);

        }

        private void BtnCosh_Click(object sender, EventArgs e)
        {
            double cosh = Convert.ToDouble(TxtResult.Text);
            cosh = Math.Cosh(cosh);
            TxtResult.Text = Convert.ToString(cosh);

        }

        private void BtnCos_Click(object sender, EventArgs e)
        {
            double cos = Convert.ToDouble(TxtResult.Text);
            cos = Math.Cos(cos);
            TxtResult.Text = Convert.ToString(cos);
        }

        private void BtnTanh_Click(object sender, EventArgs e)
        {
            double tanh = Convert.ToDouble(TxtResult.Text);
            tanh = Math.Tanh(tanh);
            TxtResult.Text = Convert.ToString(tanh);
        }

        private void BtnTan_Click(object sender, EventArgs e)
        {
            double tan = Convert.ToDouble(TxtResult.Text);
            tan = Math.Tan(tan);
            TxtResult.Text = Convert.ToString(tan);
        }

        private void Btn1x_Click(object sender, EventArgs e)
        {
            double a;
            a = Convert.ToDouble(1.0/ Convert.ToDouble(TxtResult.Text));
            TxtResult.Text = Convert.ToString(a);
        }

        private void BtnInx_Click(object sender, EventArgs e)
        {
            double lnx = Convert.ToDouble(TxtResult.Text);
            lnx = Math.Log(lnx);
            TxtResult.Text = Convert.ToString(lnx);

        }

        private void BtnPer_Click(object sender, EventArgs e)
        {
            double a;
            a = Convert.ToDouble (TxtResult.Text)/ Convert.ToDouble(100);
            TxtResult.Text = Convert.ToString(a);
        }

        private void BtnDec_Click(object sender, EventArgs e)
        {
            double dec = Convert.ToDouble(TxtResult.Text);
            int i1 = Convert.ToInt32(dec);
            int i2 = (int)dec;
            TxtResult.Text = Convert.ToString(i2);
        }

        private void BtnBin_Click(object sender, EventArgs e)
        {
            int a = int.Parse(TxtResult.Text);
            TxtResult.Text = Convert.ToString(a, 2);
        }

        private void BtnHex_Click(object sender, EventArgs e)
        {
            int a = int.Parse(TxtResult.Text);
            TxtResult.Text = Convert.ToString(a, 16);

        }

        private void BtnOct_Click(object sender, EventArgs e)
        {
            int a = int.Parse(TxtResult.Text);
            TxtResult.Text = Convert.ToString(a, 8);
        }

    }
}
