﻿namespace Scientific_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtResult = new System.Windows.Forms.TextBox();
            this.BtnBs = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnC = new System.Windows.Forms.Button();
            this.BtnMinPlus = new System.Windows.Forms.Button();
            this.BtnPlus = new System.Windows.Forms.Button();
            this.BtnNine = new System.Windows.Forms.Button();
            this.BtnEight = new System.Windows.Forms.Button();
            this.BtnSeven = new System.Windows.Forms.Button();
            this.BtnMinus = new System.Windows.Forms.Button();
            this.BtnSix = new System.Windows.Forms.Button();
            this.BtnFive = new System.Windows.Forms.Button();
            this.BtnFour = new System.Windows.Forms.Button();
            this.BtnMultiply = new System.Windows.Forms.Button();
            this.BtnThree = new System.Windows.Forms.Button();
            this.BtnTwo = new System.Windows.Forms.Button();
            this.BtnOne = new System.Windows.Forms.Button();
            this.BtnDivide = new System.Windows.Forms.Button();
            this.BtnEqual = new System.Windows.Forms.Button();
            this.BtnDot = new System.Windows.Forms.Button();
            this.BtnZero = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scientificToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnPi = new System.Windows.Forms.Button();
            this.BtnLog = new System.Windows.Forms.Button();
            this.Btnx2 = new System.Windows.Forms.Button();
            this.BtnSqrt = new System.Windows.Forms.Button();
            this.BtnX3 = new System.Windows.Forms.Button();
            this.BtnDec = new System.Windows.Forms.Button();
            this.BtnSin = new System.Windows.Forms.Button();
            this.BtnSinh = new System.Windows.Forms.Button();
            this.Btn1x = new System.Windows.Forms.Button();
            this.BtnBin = new System.Windows.Forms.Button();
            this.BtnCos = new System.Windows.Forms.Button();
            this.BtnCosh = new System.Windows.Forms.Button();
            this.BtnInx = new System.Windows.Forms.Button();
            this.BtnHex = new System.Windows.Forms.Button();
            this.BtnTan = new System.Windows.Forms.Button();
            this.BtnTanh = new System.Windows.Forms.Button();
            this.BtnPer = new System.Windows.Forms.Button();
            this.BtnOct = new System.Windows.Forms.Button();
            this.BtnMod = new System.Windows.Forms.Button();
            this.BtnExp = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TxtResult
            // 
            this.TxtResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtResult.Location = new System.Drawing.Point(36, 41);
            this.TxtResult.Multiline = true;
            this.TxtResult.Name = "TxtResult";
            this.TxtResult.Size = new System.Drawing.Size(316, 31);
            this.TxtResult.TabIndex = 0;
            this.TxtResult.Text = "0";
            this.TxtResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BtnBs
            // 
            this.BtnBs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBs.Location = new System.Drawing.Point(37, 84);
            this.BtnBs.Name = "BtnBs";
            this.BtnBs.Size = new System.Drawing.Size(76, 47);
            this.BtnBs.TabIndex = 1;
            this.BtnBs.Text = "Clear";
            this.BtnBs.UseVisualStyleBackColor = true;
            this.BtnBs.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClear.Location = new System.Drawing.Point(117, 84);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(75, 47);
            this.BtnClear.TabIndex = 2;
            this.BtnClear.Text = "CE";
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnC
            // 
            this.BtnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnC.Location = new System.Drawing.Point(198, 84);
            this.BtnC.Name = "BtnC";
            this.BtnC.Size = new System.Drawing.Size(72, 47);
            this.BtnC.TabIndex = 3;
            this.BtnC.Text = "C";
            this.BtnC.UseVisualStyleBackColor = true;
            this.BtnC.Click += new System.EventHandler(this.BtnC_Click);
            // 
            // BtnMinPlus
            // 
            this.BtnMinPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMinPlus.Location = new System.Drawing.Point(279, 84);
            this.BtnMinPlus.Name = "BtnMinPlus";
            this.BtnMinPlus.Size = new System.Drawing.Size(73, 47);
            this.BtnMinPlus.TabIndex = 4;
            this.BtnMinPlus.Text = "-+";
            this.BtnMinPlus.UseVisualStyleBackColor = true;
            this.BtnMinPlus.Click += new System.EventHandler(this.BtnMinPlus_Click);
            // 
            // BtnPlus
            // 
            this.BtnPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPlus.Location = new System.Drawing.Point(279, 137);
            this.BtnPlus.Name = "BtnPlus";
            this.BtnPlus.Size = new System.Drawing.Size(73, 47);
            this.BtnPlus.TabIndex = 8;
            this.BtnPlus.Text = "+";
            this.BtnPlus.UseVisualStyleBackColor = true;
            this.BtnPlus.Click += new System.EventHandler(this.numberOper);
            // 
            // BtnNine
            // 
            this.BtnNine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNine.Location = new System.Drawing.Point(198, 137);
            this.BtnNine.Name = "BtnNine";
            this.BtnNine.Size = new System.Drawing.Size(72, 47);
            this.BtnNine.TabIndex = 7;
            this.BtnNine.Text = "9";
            this.BtnNine.UseVisualStyleBackColor = true;
            this.BtnNine.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnEight
            // 
            this.BtnEight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEight.Location = new System.Drawing.Point(117, 137);
            this.BtnEight.Name = "BtnEight";
            this.BtnEight.Size = new System.Drawing.Size(75, 47);
            this.BtnEight.TabIndex = 6;
            this.BtnEight.Text = "8";
            this.BtnEight.UseVisualStyleBackColor = true;
            this.BtnEight.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnSeven
            // 
            this.BtnSeven.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSeven.Location = new System.Drawing.Point(37, 137);
            this.BtnSeven.Name = "BtnSeven";
            this.BtnSeven.Size = new System.Drawing.Size(76, 47);
            this.BtnSeven.TabIndex = 5;
            this.BtnSeven.Text = "7";
            this.BtnSeven.UseVisualStyleBackColor = true;
            this.BtnSeven.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnMinus
            // 
            this.BtnMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMinus.Location = new System.Drawing.Point(279, 190);
            this.BtnMinus.Name = "BtnMinus";
            this.BtnMinus.Size = new System.Drawing.Size(73, 47);
            this.BtnMinus.TabIndex = 12;
            this.BtnMinus.Text = "-";
            this.BtnMinus.UseVisualStyleBackColor = true;
            this.BtnMinus.Click += new System.EventHandler(this.numberOper);
            // 
            // BtnSix
            // 
            this.BtnSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSix.Location = new System.Drawing.Point(198, 190);
            this.BtnSix.Name = "BtnSix";
            this.BtnSix.Size = new System.Drawing.Size(72, 47);
            this.BtnSix.TabIndex = 11;
            this.BtnSix.Text = "6";
            this.BtnSix.UseVisualStyleBackColor = true;
            this.BtnSix.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnFive
            // 
            this.BtnFive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFive.Location = new System.Drawing.Point(117, 190);
            this.BtnFive.Name = "BtnFive";
            this.BtnFive.Size = new System.Drawing.Size(75, 47);
            this.BtnFive.TabIndex = 10;
            this.BtnFive.Text = "5";
            this.BtnFive.UseVisualStyleBackColor = true;
            this.BtnFive.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnFour
            // 
            this.BtnFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFour.Location = new System.Drawing.Point(37, 190);
            this.BtnFour.Name = "BtnFour";
            this.BtnFour.Size = new System.Drawing.Size(76, 47);
            this.BtnFour.TabIndex = 9;
            this.BtnFour.Text = "4";
            this.BtnFour.UseVisualStyleBackColor = true;
            this.BtnFour.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnMultiply
            // 
            this.BtnMultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMultiply.Location = new System.Drawing.Point(279, 243);
            this.BtnMultiply.Name = "BtnMultiply";
            this.BtnMultiply.Size = new System.Drawing.Size(73, 47);
            this.BtnMultiply.TabIndex = 16;
            this.BtnMultiply.Text = "*";
            this.BtnMultiply.UseVisualStyleBackColor = true;
            this.BtnMultiply.Click += new System.EventHandler(this.numberOper);
            // 
            // BtnThree
            // 
            this.BtnThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnThree.Location = new System.Drawing.Point(198, 243);
            this.BtnThree.Name = "BtnThree";
            this.BtnThree.Size = new System.Drawing.Size(72, 47);
            this.BtnThree.TabIndex = 15;
            this.BtnThree.Text = "3";
            this.BtnThree.UseVisualStyleBackColor = true;
            this.BtnThree.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnTwo
            // 
            this.BtnTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTwo.Location = new System.Drawing.Point(117, 243);
            this.BtnTwo.Name = "BtnTwo";
            this.BtnTwo.Size = new System.Drawing.Size(75, 47);
            this.BtnTwo.TabIndex = 14;
            this.BtnTwo.Text = "2";
            this.BtnTwo.UseVisualStyleBackColor = true;
            this.BtnTwo.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnOne
            // 
            this.BtnOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOne.Location = new System.Drawing.Point(37, 243);
            this.BtnOne.Name = "BtnOne";
            this.BtnOne.Size = new System.Drawing.Size(76, 47);
            this.BtnOne.TabIndex = 13;
            this.BtnOne.Text = "1";
            this.BtnOne.UseVisualStyleBackColor = true;
            this.BtnOne.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnDivide
            // 
            this.BtnDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDivide.Location = new System.Drawing.Point(279, 296);
            this.BtnDivide.Name = "BtnDivide";
            this.BtnDivide.Size = new System.Drawing.Size(73, 47);
            this.BtnDivide.TabIndex = 20;
            this.BtnDivide.Text = "/";
            this.BtnDivide.UseVisualStyleBackColor = true;
            this.BtnDivide.Click += new System.EventHandler(this.numberOper);
            // 
            // BtnEqual
            // 
            this.BtnEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEqual.Location = new System.Drawing.Point(198, 296);
            this.BtnEqual.Name = "BtnEqual";
            this.BtnEqual.Size = new System.Drawing.Size(72, 47);
            this.BtnEqual.TabIndex = 19;
            this.BtnEqual.Text = "=";
            this.BtnEqual.UseVisualStyleBackColor = true;
            this.BtnEqual.Click += new System.EventHandler(this.BtnEqual_Click);
            // 
            // BtnDot
            // 
            this.BtnDot.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDot.Location = new System.Drawing.Point(117, 296);
            this.BtnDot.Name = "BtnDot";
            this.BtnDot.Size = new System.Drawing.Size(75, 47);
            this.BtnDot.TabIndex = 18;
            this.BtnDot.Text = ".";
            this.BtnDot.UseVisualStyleBackColor = true;
            this.BtnDot.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // BtnZero
            // 
            this.BtnZero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnZero.Location = new System.Drawing.Point(37, 296);
            this.BtnZero.Name = "BtnZero";
            this.BtnZero.Size = new System.Drawing.Size(76, 47);
            this.BtnZero.TabIndex = 17;
            this.BtnZero.Text = "0";
            this.BtnZero.UseVisualStyleBackColor = true;
            this.BtnZero.Click += new System.EventHandler(this.EnterNumbers);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(838, 24);
            this.menuStrip1.TabIndex = 21;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.standardToolStripMenuItem,
            this.scientificToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // standardToolStripMenuItem
            // 
            this.standardToolStripMenuItem.Name = "standardToolStripMenuItem";
            this.standardToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.standardToolStripMenuItem.Text = "Standard";
            this.standardToolStripMenuItem.Click += new System.EventHandler(this.standardToolStripMenuItem_Click);
            // 
            // scientificToolStripMenuItem
            // 
            this.scientificToolStripMenuItem.Name = "scientificToolStripMenuItem";
            this.scientificToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.scientificToolStripMenuItem.Text = "Scientific";
            this.scientificToolStripMenuItem.Click += new System.EventHandler(this.scientificToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // BtnPi
            // 
            this.BtnPi.Font = new System.Drawing.Font("Constantia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPi.Location = new System.Drawing.Point(389, 84);
            this.BtnPi.Name = "BtnPi";
            this.BtnPi.Size = new System.Drawing.Size(73, 47);
            this.BtnPi.TabIndex = 22;
            this.BtnPi.Text = "Π";
            this.BtnPi.UseVisualStyleBackColor = true;
            this.BtnPi.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // BtnLog
            // 
            this.BtnLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLog.Location = new System.Drawing.Point(468, 84);
            this.BtnLog.Name = "BtnLog";
            this.BtnLog.Size = new System.Drawing.Size(73, 47);
            this.BtnLog.TabIndex = 23;
            this.BtnLog.Text = "Log";
            this.BtnLog.UseVisualStyleBackColor = true;
            this.BtnLog.Click += new System.EventHandler(this.BtnLog_Click);
            // 
            // Btnx2
            // 
            this.Btnx2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnx2.Location = new System.Drawing.Point(626, 84);
            this.Btnx2.Name = "Btnx2";
            this.Btnx2.Size = new System.Drawing.Size(73, 47);
            this.Btnx2.TabIndex = 25;
            this.Btnx2.Text = "x2";
            this.Btnx2.UseVisualStyleBackColor = true;
            this.Btnx2.Click += new System.EventHandler(this.Btnx2_Click);
            // 
            // BtnSqrt
            // 
            this.BtnSqrt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSqrt.Location = new System.Drawing.Point(547, 84);
            this.BtnSqrt.Name = "BtnSqrt";
            this.BtnSqrt.Size = new System.Drawing.Size(73, 47);
            this.BtnSqrt.TabIndex = 24;
            this.BtnSqrt.Text = "Sqrt";
            this.BtnSqrt.UseVisualStyleBackColor = true;
            this.BtnSqrt.Click += new System.EventHandler(this.BtnSqrt_Click);
            // 
            // BtnX3
            // 
            this.BtnX3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnX3.Location = new System.Drawing.Point(626, 137);
            this.BtnX3.Name = "BtnX3";
            this.BtnX3.Size = new System.Drawing.Size(73, 47);
            this.BtnX3.TabIndex = 29;
            this.BtnX3.Text = "x3";
            this.BtnX3.UseVisualStyleBackColor = true;
            this.BtnX3.Click += new System.EventHandler(this.BtnX3_Click);
            // 
            // BtnDec
            // 
            this.BtnDec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDec.Location = new System.Drawing.Point(547, 137);
            this.BtnDec.Name = "BtnDec";
            this.BtnDec.Size = new System.Drawing.Size(73, 47);
            this.BtnDec.TabIndex = 28;
            this.BtnDec.Text = "Dec";
            this.BtnDec.UseVisualStyleBackColor = true;
            this.BtnDec.Click += new System.EventHandler(this.BtnDec_Click);
            // 
            // BtnSin
            // 
            this.BtnSin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSin.Location = new System.Drawing.Point(468, 137);
            this.BtnSin.Name = "BtnSin";
            this.BtnSin.Size = new System.Drawing.Size(73, 47);
            this.BtnSin.TabIndex = 27;
            this.BtnSin.Text = "Sin";
            this.BtnSin.UseVisualStyleBackColor = true;
            this.BtnSin.Click += new System.EventHandler(this.BtnSin_Click);
            // 
            // BtnSinh
            // 
            this.BtnSinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSinh.Location = new System.Drawing.Point(389, 137);
            this.BtnSinh.Name = "BtnSinh";
            this.BtnSinh.Size = new System.Drawing.Size(73, 47);
            this.BtnSinh.TabIndex = 26;
            this.BtnSinh.Text = "Sinh";
            this.BtnSinh.UseVisualStyleBackColor = true;
            this.BtnSinh.Click += new System.EventHandler(this.BtnSinh_Click);
            // 
            // Btn1x
            // 
            this.Btn1x.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn1x.Location = new System.Drawing.Point(626, 190);
            this.Btn1x.Name = "Btn1x";
            this.Btn1x.Size = new System.Drawing.Size(73, 47);
            this.Btn1x.TabIndex = 33;
            this.Btn1x.Text = "1/x";
            this.Btn1x.UseVisualStyleBackColor = true;
            this.Btn1x.Click += new System.EventHandler(this.Btn1x_Click);
            // 
            // BtnBin
            // 
            this.BtnBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBin.Location = new System.Drawing.Point(547, 190);
            this.BtnBin.Name = "BtnBin";
            this.BtnBin.Size = new System.Drawing.Size(73, 47);
            this.BtnBin.TabIndex = 32;
            this.BtnBin.Text = "Bin";
            this.BtnBin.UseVisualStyleBackColor = true;
            this.BtnBin.Click += new System.EventHandler(this.BtnBin_Click);
            // 
            // BtnCos
            // 
            this.BtnCos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCos.Location = new System.Drawing.Point(468, 190);
            this.BtnCos.Name = "BtnCos";
            this.BtnCos.Size = new System.Drawing.Size(73, 47);
            this.BtnCos.TabIndex = 31;
            this.BtnCos.Text = "Cos";
            this.BtnCos.UseVisualStyleBackColor = true;
            this.BtnCos.Click += new System.EventHandler(this.BtnCos_Click);
            // 
            // BtnCosh
            // 
            this.BtnCosh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCosh.Location = new System.Drawing.Point(389, 190);
            this.BtnCosh.Name = "BtnCosh";
            this.BtnCosh.Size = new System.Drawing.Size(73, 47);
            this.BtnCosh.TabIndex = 30;
            this.BtnCosh.Text = "Cosh";
            this.BtnCosh.UseVisualStyleBackColor = true;
            this.BtnCosh.Click += new System.EventHandler(this.BtnCosh_Click);
            // 
            // BtnInx
            // 
            this.BtnInx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInx.Location = new System.Drawing.Point(626, 243);
            this.BtnInx.Name = "BtnInx";
            this.BtnInx.Size = new System.Drawing.Size(73, 47);
            this.BtnInx.TabIndex = 37;
            this.BtnInx.Text = "In x";
            this.BtnInx.UseVisualStyleBackColor = true;
            this.BtnInx.Click += new System.EventHandler(this.BtnInx_Click);
            // 
            // BtnHex
            // 
            this.BtnHex.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHex.Location = new System.Drawing.Point(547, 243);
            this.BtnHex.Name = "BtnHex";
            this.BtnHex.Size = new System.Drawing.Size(73, 47);
            this.BtnHex.TabIndex = 36;
            this.BtnHex.Text = "Hex";
            this.BtnHex.UseVisualStyleBackColor = true;
            this.BtnHex.Click += new System.EventHandler(this.BtnHex_Click);
            // 
            // BtnTan
            // 
            this.BtnTan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTan.Location = new System.Drawing.Point(468, 243);
            this.BtnTan.Name = "BtnTan";
            this.BtnTan.Size = new System.Drawing.Size(73, 47);
            this.BtnTan.TabIndex = 35;
            this.BtnTan.Text = "Tan";
            this.BtnTan.UseVisualStyleBackColor = true;
            this.BtnTan.Click += new System.EventHandler(this.BtnTan_Click);
            // 
            // BtnTanh
            // 
            this.BtnTanh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTanh.Location = new System.Drawing.Point(389, 243);
            this.BtnTanh.Name = "BtnTanh";
            this.BtnTanh.Size = new System.Drawing.Size(73, 47);
            this.BtnTanh.TabIndex = 34;
            this.BtnTanh.Text = "Tanh";
            this.BtnTanh.UseVisualStyleBackColor = true;
            this.BtnTanh.Click += new System.EventHandler(this.BtnTanh_Click);
            // 
            // BtnPer
            // 
            this.BtnPer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPer.Location = new System.Drawing.Point(626, 296);
            this.BtnPer.Name = "BtnPer";
            this.BtnPer.Size = new System.Drawing.Size(73, 47);
            this.BtnPer.TabIndex = 41;
            this.BtnPer.Text = "%";
            this.BtnPer.UseVisualStyleBackColor = true;
            this.BtnPer.Click += new System.EventHandler(this.BtnPer_Click);
            // 
            // BtnOct
            // 
            this.BtnOct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOct.Location = new System.Drawing.Point(547, 296);
            this.BtnOct.Name = "BtnOct";
            this.BtnOct.Size = new System.Drawing.Size(73, 47);
            this.BtnOct.TabIndex = 40;
            this.BtnOct.Text = "Oct";
            this.BtnOct.UseVisualStyleBackColor = true;
            this.BtnOct.Click += new System.EventHandler(this.BtnOct_Click);
            // 
            // BtnMod
            // 
            this.BtnMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMod.Location = new System.Drawing.Point(468, 296);
            this.BtnMod.Name = "BtnMod";
            this.BtnMod.Size = new System.Drawing.Size(73, 47);
            this.BtnMod.TabIndex = 39;
            this.BtnMod.Text = "Mod";
            this.BtnMod.UseVisualStyleBackColor = true;
            this.BtnMod.Click += new System.EventHandler(this.numberOper);
            // 
            // BtnExp
            // 
            this.BtnExp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExp.Location = new System.Drawing.Point(389, 296);
            this.BtnExp.Name = "BtnExp";
            this.BtnExp.Size = new System.Drawing.Size(73, 47);
            this.BtnExp.TabIndex = 38;
            this.BtnExp.Text = "Exp";
            this.BtnExp.UseVisualStyleBackColor = true;
            this.BtnExp.Click += new System.EventHandler(this.numberOper);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(838, 408);
            this.Controls.Add(this.BtnPer);
            this.Controls.Add(this.BtnOct);
            this.Controls.Add(this.BtnMod);
            this.Controls.Add(this.BtnExp);
            this.Controls.Add(this.BtnInx);
            this.Controls.Add(this.BtnHex);
            this.Controls.Add(this.BtnTan);
            this.Controls.Add(this.BtnTanh);
            this.Controls.Add(this.Btn1x);
            this.Controls.Add(this.BtnBin);
            this.Controls.Add(this.BtnCos);
            this.Controls.Add(this.BtnCosh);
            this.Controls.Add(this.BtnX3);
            this.Controls.Add(this.BtnDec);
            this.Controls.Add(this.BtnSin);
            this.Controls.Add(this.BtnSinh);
            this.Controls.Add(this.Btnx2);
            this.Controls.Add(this.BtnSqrt);
            this.Controls.Add(this.BtnLog);
            this.Controls.Add(this.BtnPi);
            this.Controls.Add(this.BtnDivide);
            this.Controls.Add(this.BtnEqual);
            this.Controls.Add(this.BtnDot);
            this.Controls.Add(this.BtnZero);
            this.Controls.Add(this.BtnMultiply);
            this.Controls.Add(this.BtnThree);
            this.Controls.Add(this.BtnTwo);
            this.Controls.Add(this.BtnOne);
            this.Controls.Add(this.BtnMinus);
            this.Controls.Add(this.BtnSix);
            this.Controls.Add(this.BtnFive);
            this.Controls.Add(this.BtnFour);
            this.Controls.Add(this.BtnPlus);
            this.Controls.Add(this.BtnNine);
            this.Controls.Add(this.BtnEight);
            this.Controls.Add(this.BtnSeven);
            this.Controls.Add(this.BtnMinPlus);
            this.Controls.Add(this.BtnC);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnBs);
            this.Controls.Add(this.TxtResult);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtResult;
        private System.Windows.Forms.Button BtnBs;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Button BtnC;
        private System.Windows.Forms.Button BtnMinPlus;
        private System.Windows.Forms.Button BtnPlus;
        private System.Windows.Forms.Button BtnNine;
        private System.Windows.Forms.Button BtnEight;
        private System.Windows.Forms.Button BtnSeven;
        private System.Windows.Forms.Button BtnMinus;
        private System.Windows.Forms.Button BtnSix;
        private System.Windows.Forms.Button BtnFive;
        private System.Windows.Forms.Button BtnFour;
        private System.Windows.Forms.Button BtnMultiply;
        private System.Windows.Forms.Button BtnThree;
        private System.Windows.Forms.Button BtnTwo;
        private System.Windows.Forms.Button BtnOne;
        private System.Windows.Forms.Button BtnDivide;
        private System.Windows.Forms.Button BtnEqual;
        private System.Windows.Forms.Button BtnDot;
        private System.Windows.Forms.Button BtnZero;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scientificToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button BtnPi;
        private System.Windows.Forms.Button BtnLog;
        private System.Windows.Forms.Button Btnx2;
        private System.Windows.Forms.Button BtnSqrt;
        private System.Windows.Forms.Button BtnX3;
        private System.Windows.Forms.Button BtnDec;
        private System.Windows.Forms.Button BtnSin;
        private System.Windows.Forms.Button BtnSinh;
        private System.Windows.Forms.Button Btn1x;
        private System.Windows.Forms.Button BtnBin;
        private System.Windows.Forms.Button BtnCos;
        private System.Windows.Forms.Button BtnCosh;
        private System.Windows.Forms.Button BtnInx;
        private System.Windows.Forms.Button BtnHex;
        private System.Windows.Forms.Button BtnTan;
        private System.Windows.Forms.Button BtnTanh;
        private System.Windows.Forms.Button BtnPer;
        private System.Windows.Forms.Button BtnOct;
        private System.Windows.Forms.Button BtnMod;
        private System.Windows.Forms.Button BtnExp;
    }
}

